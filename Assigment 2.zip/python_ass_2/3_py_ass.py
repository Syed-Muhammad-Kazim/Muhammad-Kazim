list = ["1", "2", "3"]

print(list)
print("Length of list: ",len(list))
