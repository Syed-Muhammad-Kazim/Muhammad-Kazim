list = [1, 99, 145, 21]
print(list)
print("largest no is:",max(list))
