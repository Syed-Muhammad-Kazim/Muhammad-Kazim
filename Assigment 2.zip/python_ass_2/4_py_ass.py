list = [1, 2, 3, 4, 5]

sum = sum(list)

print(list)
print("Sum of all in list: ",sum)
