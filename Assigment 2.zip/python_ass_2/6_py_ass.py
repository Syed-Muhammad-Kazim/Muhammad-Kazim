a = [1,1,2,3,4,8,13,21,34,55,89]

print(a)

for i in a:
 if i<5:
  print(i)


