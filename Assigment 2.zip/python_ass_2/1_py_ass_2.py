sub1 = int(input("Math:"))
sub2 = int(input("Physics:"))
sub3 = int(input("Calculus:"))
sub4 = int(input("Oop:"))
sub5 = int(input("Cs:"))

total = (sub1+sub2+sub3+sub4+sub5)

print("Total Marks: ",total)
maxMarks = 500
percentage = (total/maxMarks) * 100

if percentage >= 50:
 print("Percentage: ",percentage,"%")
 print("C Grade") 
elif percentage >= 60:
 print("Percentage: ",percentage,"%")
 print("B Grade")
elif percentage >= 70: 
 print("Percentage: ",percentage,"%")
 print("A Grade")
elif percentage >= 50: 
 print("Percentage: ",percentage,"%")
 print("A+ Grade")
else:
 print("Percentage: ",percentage,"%")
 print("F Grade")

 


