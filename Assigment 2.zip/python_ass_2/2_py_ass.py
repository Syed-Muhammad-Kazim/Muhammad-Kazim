n = int(input("Enter your digit:"))

if n%2 == 0:
 print("EVEN")
else:
 print("ODD")
