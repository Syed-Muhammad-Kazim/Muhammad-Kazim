dict = {0:1, 1:10}
print(dict)

dict.update({2:100})
print(dict)
