dict = {"a":100, "b":200, "c":400}

key = 'b'

if key in dict.keys():
 print("Yes there is", "value =", dict[key])
 print(dict)
else:
 print('No there is not')

