d = {'p1':400,'p2':-5,'p3':204}
print(d)
print(sum(d.values()))
